"""An archive that a local index serves."""

__version__ = "1.0.0"
