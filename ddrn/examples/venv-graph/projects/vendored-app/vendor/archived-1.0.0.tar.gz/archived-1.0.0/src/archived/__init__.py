"""A distribution that no index serves."""

__version__ = "1.0.0"
